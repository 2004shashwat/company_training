@Logins
Feature: Login

  @SingleLogin
  Scenario: Login into application
    Given launch "Orange HRM" application
    When Login into application using "Testdata1"
    Then verify user is logged in


    @MultipleLogin
    Scenario Outline: Login into application with different users
      Given launch "Orange HRM" application
      When Login into application using "<Testdata>"
      Then verify user is logged in
      Examples:
      |Testdata|
      |Testdata1|
      |Testdata2|
