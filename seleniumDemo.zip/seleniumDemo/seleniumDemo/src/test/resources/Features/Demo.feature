Feature: Adding item in YoKart website

  @demo
  Scenario: Adding item in YoKart website
    Given launch "YoKart" application
    When user click on "Sign In"
    Then verify user is logged in
    And Navigate to Categories
